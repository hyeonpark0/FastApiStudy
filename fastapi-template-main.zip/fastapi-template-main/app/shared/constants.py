from enum import Enum

class Tags(Enum):
    courses: str = 'courses'
    items = 'items'
    users = 'users'
